// lib/provider/user_provider.dart

import 'package:flutter/material.dart';

class UserProvider with ChangeNotifier {
  String? _token;
  String? _username;

  String? get token => _token;
  String? get username => _username;

  void setToken(String token, {required String username}) {
    _token = token;
    _username = username;
    notifyListeners();
  }

  void logout() {
    _token = null;
    _username = null;
    notifyListeners();
  }

  bool get isLogged => _token != null;
}
