// lib/services/product_service.dart

import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:appdeliverytb/services/api_service.dart';
import 'package:appdeliverytb/model/product_model.dart';

class ProductService {
  static Future<List<Product>> fetchByRestaurant(
      BuildContext context, int restaurantId) async {
    
    final response = await ApiService.get(
      context,
      '/products?restaurant=$restaurantId', // CORRIGIDO
    );

    if (response.statusCode == 200) {
      final jsonData = jsonDecode(response.body);

      // Supondo que o backend retorna {"data": [...produtos...]}
      final List<dynamic> products = jsonData["data"] ?? [];

      return products
          .map((e) => Product.fromJson(Map<String, dynamic>.from(e)))
          .toList();
    } else {
      throw Exception("Erro ao buscar produtos");
    }
  }
}
