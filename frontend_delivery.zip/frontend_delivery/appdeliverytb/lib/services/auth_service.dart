// lib/services/auth_service.dart

import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:appdeliverytb/services/api_service.dart';

class AuthService {
  /// LOGIN
  static Future<String> login(String username, String password) async {
    final response = await http.post(
      Uri.parse('${ApiService.baseUrl}/login/'), // confirme o endpoint
      headers: {
        'Content-Type': 'application/json',
      },
      body: jsonEncode({
        'username': username,
        'password': password,
      }),
    );

    if (response.statusCode == 200) {
      final json = jsonDecode(response.body);

      // EXIGE que tenha campo "token"
      if (json['token'] == null) {
        throw Exception("Resposta inválida do servidor: token ausente");
      }

      return json['token']; // <-- retorna STRING
    }

    throw Exception("Falha no login (${response.statusCode})");
  }

  /// REGISTER
  static Future<bool> register(String username, String password) async {
    final response = await http.post(
      Uri.parse('${ApiService.baseUrl}/register/'), // confirme
      headers: {
        'Content-Type': 'application/json',
      },
      body: jsonEncode({
        'username': username,
        'password': password,
      }),
    );

    return response.statusCode == 201 || response.statusCode == 200;
  }
}
