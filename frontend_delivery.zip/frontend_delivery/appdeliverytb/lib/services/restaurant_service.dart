// lib/services/restaurant_service.dart

import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:appdeliverytb/services/api_service.dart';
import 'package:appdeliverytb/model/restaurant.dart';

class RestaurantService {
  static Future<List<RestaurantModel>> fetchAll(BuildContext context) async {
    final response = await ApiService.get(context, '/restaurants');

    if (response.statusCode == 200) {
      final jsonData = jsonDecode(response.body);

      final List<dynamic> restaurants = jsonData["data"] ?? [];

      return restaurants
          .map((e) => RestaurantModel.fromJson(Map<String, dynamic>.from(e)))
          .toList();
    } else {
      throw Exception("Erro ao carregar restaurantes");
    }
  }

  static Future<List<RestaurantModel>> fetchByCategory(
      BuildContext context, int categoryId) async {
    
    final response = await ApiService.get(
      context,
      '/restaurants?category=$categoryId',
    );

    if (response.statusCode == 200) {
      final jsonData = jsonDecode(response.body);

      final List<dynamic> restaurants = jsonData["data"] ?? [];

      return restaurants
          .map((e) => RestaurantModel.fromJson(Map<String, dynamic>.from(e)))
          .toList();
    } else {
      throw Exception("Erro ao carregar restaurantes por categoria");
    }
  }
}
