// lib/services/category_service.dart
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:appdeliverytb/services/api_service.dart';

class CategoryService {
  static Future<List<dynamic>> fetchAll(BuildContext context) async {
    final response = await ApiService.get(context, '/categories');

    if (response.statusCode == 200) {
      final jsonData = jsonDecode(response.body);

      // Supondo que o backend retorna:
      // { "data": [ ...categorias... ] }
      return jsonData["data"] ?? [];
    } else {
      throw Exception('Erro ao carregar categorias');
    }
  }
}
