import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:provider/provider.dart';
import 'package:flutter/material.dart';
import '../provider/user_provider.dart';

class ApiService {
  static const String baseUrl = "http://10.0.2.2:8000/api";

  static Future<http.Response> get(
      BuildContext context, String endpoint) async {
    final token = Provider.of<UserProvider>(context, listen: false).token;

    return http.get(
      Uri.parse("$baseUrl$endpoint"),
      headers: {
        "Content-Type": "application/json",
        if (token != null) "Authorization": "Bearer $token",
      },
    );
  }

  static Future<http.Response> post(
      BuildContext context, String endpoint, Map<String, dynamic> body) async {
    final token = Provider.of<UserProvider>(context, listen: false).token;

    return http.post(
      Uri.parse("$baseUrl$endpoint"),
      headers: {
        "Content-Type": "application/json",
        if (token != null) "Authorization": "Bearer $token",
      },
      body: jsonEncode(body),
    );
  }
}
