// lib/data/restaurant_data.dart
import 'package:flutter/material.dart';
import 'package:appdeliverytb/services/restaurant_service.dart';
import 'package:appdeliverytb/model/restaurant.dart';

class RestaurantData extends ChangeNotifier {
  List<RestaurantModel> _list = [];
  List<RestaurantModel> get listRestaurant => _list;

  bool get hasData => _list.isNotEmpty;

  Future<List<RestaurantModel>> loadOnce() async {
    if (_list.isNotEmpty) return _list;
    try {
      _list = await RestaurantService.fetchAll();
      notifyListeners();
    } catch (e) {
      debugPrint('Erro ao carregar restaurantes: $e');
    }
    return _list;
  }

  void clear() {
    _list = [];
    notifyListeners();
  }
}
