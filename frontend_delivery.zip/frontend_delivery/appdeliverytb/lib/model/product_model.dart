// lib/model/product_model.dart
class Product {
  final int id;
  final String name;
  final String description;
  final double price;
  final int? restaurant;

  Product({
    required this.id,
    required this.name,
    required this.description,
    required this.price,
    this.restaurant,
  });

  factory Product.fromJson(Map<String, dynamic> json) => Product(
        id: json['id'],
        name: json['name'] ?? json['nome'] ?? '',
        description: json['description'] ?? json['descricao'] ?? '',
        price: double.tryParse(json['price']?.toString() ?? json['preco']?.toString() ?? '0') ?? 0.0,
        restaurant: json['restaurant'] ?? json['restaurante'],
      );
}
