// lib/model/restaurant.dart
class RestaurantModel {
  final int id;
  final String name;
  final String image;
  final String description;
  final int? category; // id da categoria ou null
  final List<dynamic>? products; // caso o backend anexe produtos

  RestaurantModel({
    required this.id,
    required this.name,
    required this.image,
    required this.description,
    this.category,
    this.products,
  });

  factory RestaurantModel.fromJson(Map<String, dynamic> json) {
    return RestaurantModel(
      id: json['id'],
      name: json['name'] ?? json['nome'] ?? '',
      image: json['image'] ?? json['imagem'] ?? '',
      description: json['description'] ?? json['descricao'] ?? '',
      category: json['category'] is int ? json['category'] : (json['category'] != null ? int.tryParse(json['category'].toString()) : null),
      products: json['products'] != null ? List.from(json['products']) : null,
    );
  }
}
