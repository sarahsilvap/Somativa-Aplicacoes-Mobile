package com.exampleaula06apptb.appdeliverytb

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
